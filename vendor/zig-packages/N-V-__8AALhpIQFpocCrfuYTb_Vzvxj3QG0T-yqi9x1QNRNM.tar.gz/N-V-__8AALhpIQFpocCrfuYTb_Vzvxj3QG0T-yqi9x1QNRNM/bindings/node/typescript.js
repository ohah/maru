module.exports = require('.').typescript;
