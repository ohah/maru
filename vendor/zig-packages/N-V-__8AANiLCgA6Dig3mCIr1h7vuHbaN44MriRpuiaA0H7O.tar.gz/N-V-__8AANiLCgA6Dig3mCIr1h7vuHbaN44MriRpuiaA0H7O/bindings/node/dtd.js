module.exports = require('.').dtd;
