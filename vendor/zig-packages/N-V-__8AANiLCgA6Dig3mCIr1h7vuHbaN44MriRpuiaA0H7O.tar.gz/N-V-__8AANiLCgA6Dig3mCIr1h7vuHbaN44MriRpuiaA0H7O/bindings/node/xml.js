module.exports = require('.').xml;
